# Export complet du code — ANIAUX

Note: Les fichiers d’assets (images/svg volumineux) et package-lock.json sont exclus pour garder un document lisible. Le code applicatif et les configurations principales sont inclus.

---

Chemin: /.gitignore

```
# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

node_modules
dist
dist-ssr
*.local

# Editor directories and files
.vscode/*
!.vscode/extensions.json
.idea
.DS_Store
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?
```

---

Chemin: /package.json

```json
{
  "name": "aniaux",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "eslint .",
    "preview": "vite preview"
  },
  "dependencies": {
    "framer-motion": "^12.34.0",
    "lucide-react": "^0.564.0",
    "react": "^19.2.0",
    "react-dom": "^19.2.0"
  },
  "devDependencies": {
    "@eslint/js": "^9.39.1",
    "@types/react": "^19.2.7",
    "@types/react-dom": "^19.2.3",
    "@vitejs/plugin-react": "^5.1.1",
    "autoprefixer": "^10.4.24",
    "eslint": "^9.39.1",
    "eslint-plugin-react-hooks": "^7.0.1",
    "eslint-plugin-react-refresh": "^0.4.24",
    "globals": "^16.5.0",
    "postcss": "^8.5.6",
    "tailwindcss": "^4.1.18",
    "vite": "^8.0.0-beta.13"
  },
  "overrides": {
    "vite": "^8.0.0-beta.13"
  }
}
```

---

Chemin: /vite.config.js

```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    host: true,
  },
})
```

---

Chemin: /eslint.config.js

```js
import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{js,jsx}'],
    extends: [
      js.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
      parserOptions: {
        ecmaVersion: 'latest',
        ecmaFeatures: { jsx: true },
        sourceType: 'module',
      },
    },
    rules: {
      'no-unused-vars': ['error', { varsIgnorePattern: '^[A-Z_]' }],
    },
  },
])
```

---

Chemin: /index.html

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>aniaux</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
```

---

Chemin: /README.md

```md
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) (or [oxc](https://oxc.rs) when used in [rolldown-vite](https://vite.dev/guide/rolldown)) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.
```

---

Chemin: /src/index.css

```css
@import "tailwindcss";
```

---

Chemin: /src/main.jsx

```jsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
```

---

Chemin: /src/App.jsx

```jsx
import React, { useState } from 'react';
import { motion as Motion, AnimatePresence } from 'framer-motion';
import { Heart, Sparkles, Check, Star, ChevronDown, Upload, CreditCard, CheckCircle } from 'lucide-react';

export default function App() {
  const [page, setPage] = useState('landing');
  const [step, setStep] = useState(1);
  const [openFaq, setOpenFaq] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [form, setForm] = useState({ ownerName: '', ownerEmail: '', petName: '', package: 'premium' });

  const testimonials = [
    { name: "Sophie M.", text: "Album magnifique ❤️", stars: 5 },
    { name: "Thomas L.", text: "Parfait pour Luna", stars: 5 },
    { name: "Marie D.", text: "Cadeau idéal !", stars: 5 },
  ];

  const faqs = [
    { q: "Combien de photos ?", a: "15 Basic, 30 Premium, illimité Ultimate" },
    { q: "Délai ?", a: "48-72h après paiement" },
    { q: "Mobile ?", a: "Oui, 100% responsive" },
  ];

  const prices = { basic: 35, premium: 65, ultimate: 120 };

  if (page === 'landing') {
    return (
      <div className="bg-black text-white">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-600/30 via-purple-600/30 to-blue-600/30" />
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1600')", backgroundSize: 'cover' }} />
          
          {[0, 1, 2].map(i => (
            <Motion.div key={i} className="absolute w-96 h-96 rounded-full blur-3xl" 
              style={{ background: `radial-gradient(circle, ${['rgba(236,72,153,0.25)', 'rgba(139,92,246,0.25)', 'rgba(59,130,246,0.25)'][i]}, transparent)`, left: `${i * 30}%`, top: `${i * 20}%` }} 
              animate={{ x: [0, 50, 0], y: [0, 30, 0] }} transition={{ duration: 15, repeat: Infinity }} />
          ))}

          <div className="relative z-10 text-center px-4 max-w-5xl">
            <Motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }} className="mb-8">
              <div className="inline-block p-6 rounded-full bg-gradient-to-br from-pink-500 to-purple-600"><Heart className="w-16 h-16" fill="white" /></div>
            </Motion.div>
            <Motion.h1 initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-6xl md:text-8xl font-black mb-6">
              <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">L'Album Interactif</span>
              <br/><span className="text-white">Qui Célèbre</span>
              <br/><span className="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Votre Amour à 4 Pattes</span>
            </Motion.h1>
            <Motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="text-xl text-gray-300 mb-10">
              Un héritage numérique émotionnel pour immortaliser votre compagnon
            </Motion.p>
            <Motion.button onClick={() => setPage('order')} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.9 }}
              whileHover={{ scale: 1.05 }} className="px-12 py-6 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full text-xl font-bold">
              <Sparkles className="inline w-6 h-6 mr-2" />Créer Mon Album<Sparkles className="inline w-6 h-6 ml-2" />
            </Motion.button>
          </div>
          <Motion.div className="absolute bottom-10 left-1/2 -translate-x-1/2" animate={{ y: [0, 15, 0] }} transition={{ duration: 2, repeat: Infinity }}>
            <ChevronDown className="w-12 h-12 text-pink-400" />
          </Motion.div>
        </section>

        <section className="py-32 px-4 bg-gradient-to-b from-black via-purple-950/20 to-black">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-20 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Simple</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[{ num: "01", title: "Commandez", icon: "🛒" }, { num: "02", title: "Envoyez", icon: "📸" }, { num: "03", title: "Recevez", icon: "🎁" }].map((s, i) => (
                <Motion.div key={i} initial={{ opacity: 0, y: 100 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="group relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-600/20 to-purple-600/20 rounded-3xl blur-xl" />
                  <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
                    <div className="text-8xl mb-6 opacity-50 font-black bg-gradient-to-br from-pink-500 to-purple-500 bg-clip-text text-transparent">{s.num}</div>
                    <div className="text-7xl mb-6">{s.icon}</div>
                    <h3 className="text-3xl font-bold text-white">{s.title}</h3>
                  </div>
                </Motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-32 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-20 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Tarifs</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { name: "BASIC", price: "35€", features: ["15 photos", "Timeline", "Compteur"] },
                { name: "PREMIUM", price: "65€", features: ["30 photos", "Vidéos", "Musique"], popular: true },
                { name: "ULTIMATE", price: "120€", features: ["Illimité", "Hommage", "Livre d'or"] }
              ].map((o, i) => (
                <Motion.div key={i} initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="relative">
                  {o.popular && <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-6 py-2 rounded-full font-bold text-sm">⭐ POPULAIRE</div>}
                  <div className="bg-gradient-to-br from-pink-600 to-purple-600 rounded-3xl p-10 border-2 border-white/20">
                    <h3 className="text-3xl font-black mb-4 text-white">{o.name}</h3>
                    <div className="text-6xl font-black mb-4 text-white">{o.price}</div>
                    <ul className="space-y-4 mb-10">
                      {o.features.map(f => <li key={f} className="flex items-center gap-2 text-white"><Check className="w-6 h-6" />{f}</li>)}
                    </ul>
                    <button onClick={() => setPage('order')} className="w-full py-5 rounded-full font-bold text-lg bg-white text-purple-600">Commander</button>
                  </div>
                </Motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 overflow-hidden">
          <h2 className="text-7xl font-black text-center mb-16 text-white">Avis</h2>
          <Motion.div className="flex gap-6" animate={{ x: ['0%', '-50%'] }} transition={{ duration: 30, repeat: Infinity, ease: "linear" }}>
            {[...testimonials, ...testimonials, ...testimonials].map((t, i) => (
              <div key={i} className="flex-shrink-0 w-96 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8">
                <div className="flex gap-1 mb-4">{[...Array(t.stars)].map((_, j) => <Star key={j} className="w-4 h-4 text-yellow-400" fill="currentColor" />)}</div>
                <p className="text-lg italic text-white">"{t.text}"</p>
                <p className="font-bold mt-4 text-white">— {t.name}</p>
              </div>
            ))}
          </Motion.div>
        </section>

        <section className="py-32 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-16 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">FAQ</h2>
            {faqs.map((faq, i) => (
              <Motion.div key={i} className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl mb-4" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
                <button className="w-full p-6 text-left font-bold text-lg flex justify-between text-white" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {faq.q}
                  <ChevronDown className={`w-6 h-6 text-pink-400 transition ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openFaq === i && <Motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-400">{faq.a}</Motion.div>}
                </AnimatePresence>
              </Motion.div>
            ))}
          </div>
        </section>

        <section className="py-32 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-600 via-purple-600 to-blue-600" />
          <div className="relative text-center">
            <h2 className="text-8xl font-black mb-8 text-white">Prêt ?</h2>
            <button onClick={() => setPage('order')} className="px-16 py-8 bg-white text-purple-600 rounded-full text-2xl font-black">
              <Sparkles className="inline w-8 h-8 mr-2" />Créer Maintenant<Sparkles className="inline w-8 h-8 ml-2" />
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <button onClick={() => setPage('landing')} className="mb-8 text-gray-400 hover:text-white">← Retour</button>

        <div className="mb-16 flex justify-between">
          {['Formule', 'Infos', 'Photos', 'Paiement', 'Confirmé'].map((s, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className={`w-14 h-14 rounded-full flex items-center justify-center font-bold border-2 ${step > i ? 'bg-green-500 border-green-400' : step === i + 1 ? 'bg-pink-500 border-pink-400' : 'bg-white/5 border-white/20'}`}>
                {step > i ? <Check className="w-6 h-6" /> : i + 1}
              </div>
              <span className="text-xs mt-3 text-gray-400">{s}</span>
            </div>
          ))}
        </div>

        {step === 1 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Choisissez</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {['basic', 'premium', 'ultimate'].map(pkg => (
                <div key={pkg} onClick={() => setForm({...form, package: pkg})} className={`cursor-pointer bg-white/5 border-2 ${form.package === pkg ? 'border-pink-400' : 'border-white/10'} rounded-2xl p-8`}>
                  <h3 className="text-2xl font-bold mb-3 uppercase text-white">{pkg}</h3>
                  <div className="text-5xl font-black text-pink-400">{prices[pkg]}€</div>
                </div>
              ))}
            </div>
            <button onClick={() => setStep(2)} className="w-full mt-12 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full text-xl font-bold">Continuer →</button>
          </Motion.div>
        )}

        {step === 2 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Infos</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10 space-y-6">
              <input type="text" placeholder="Votre nom" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl text-white" value={form.ownerName} onChange={e => setForm({...form, ownerName: e.target.value})} />
              <input type="email" placeholder="Votre email" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl text-white" value={form.ownerEmail} onChange={e => setForm({...form, ownerEmail: e.target.value})} />
              <input type="text" placeholder="Nom animal ❤️" className="w-full p-5 bg-white/5 border-2 border-pink-400/50 rounded-xl text-2xl font-bold text-white" value={form.petName} onChange={e => setForm({...form, petName: e.target.value})} />
            </div>
            <div className="flex gap-4 mt-10">
              <button onClick={() => setStep(1)} className="flex-1 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
              <button onClick={() => setStep(3)} className="flex-1 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-bold">Continuer →</button>
            </div>
          </Motion.div>
        )}

        {step === 3 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Photos</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
              <label className="flex flex-col items-center border-4 border-dashed border-pink-400/30 rounded-2xl p-16 cursor-pointer hover:border-pink-400">
                <Upload className="w-20 h-20 text-pink-400 mb-6" />
                <span className="text-2xl font-bold text-white">Ajoutez photos</span>
                <input type="file" multiple accept="image/*" onChange={(e) => setPhotos(Array.from(e.target.files))} className="hidden" />
              </label>
              {photos.length > 0 && <p className="mt-6 text-xl font-bold text-white">{photos.length} photo(s)</p>}
            </div>
            <div className="flex gap-4 mt-10">
              <button onClick={() => setStep(2)} className="flex-1 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
              <button onClick={() => setStep(4)} disabled={photos.length === 0} className="flex-1 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-bold disabled:opacity-30">Continuer →</button>
            </div>
          </Motion.div>
        )}

        {step === 4 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Paiement</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
              <div className="bg-white/5 rounded-2xl p-6 mb-6">
                <div className="flex justify-between text-3xl font-black text-white"><span>TOTAL</span><span className="text-pink-400">{prices[form.package]}€</span></div>
              </div>
              <input type="text" placeholder="Carte" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl mb-4 text-white" />
              <button onClick={() => setStep(5)} className="w-full py-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full text-xl font-bold flex items-center justify-center gap-3">
                <CreditCard className="w-6 h-6" />Payer {prices[form.package]}€
              </button>
            </div>
            <button onClick={() => setStep(3)} className="w-full mt-6 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
          </Motion.div>
        )}

        {step === 5 && (
          <Motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center">
            <div className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 backdrop-blur-xl border border-green-400/30 rounded-3xl p-16">
              <CheckCircle className="w-32 h-32 text-green-400 mx-auto mb-8" />
              <h2 className="text-6xl font-black mb-6 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">Validé ! 🎉</h2>
              <p className="text-2xl mb-4 text-white">Album pour <span className="font-bold text-pink-400">{form.petName}</span></p>
              <p className="text-5xl font-black text-green-400 mb-12">48-72h</p>
              <button onClick={() => setPage('landing')} className="text-gray-400 hover:text-white">← Retour</button>
            </div>
          </Motion.div>
        )}
      </div>
    </div>
  );
}
```

---

Chemin: /src/App.css

```css
#root {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
}

.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.react:hover {
  filter: drop-shadow(0 0 2em #61dafbaa);
}

@keyframes logo-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@media (prefers-reduced-motion: no-preference) {
  a:nth-of-type(2) .logo {
    animation: logo-spin infinite 20s linear;
  }
}

.card {
  padding: 2em;
}

.read-the-docs {
  color: #888;
}
```

---

Chemin: /src/LandingPage.jsx

```jsx
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, Camera, Sparkles, Check, Star, ChevronDown } from 'lucide-react';

export default function LandingPage() {
  const [openFaq, setOpenFaq] = useState(null);

  const testimonials = [
    { name: "Sophie M.", text: "J'ai pleuré en découvrant l'album de mon Max. Un trésor éternel ❤️", stars: 5 },
    { name: "Thomas L.", text: "Magnifique hommage à ma chatte Luna. Merci infiniment.", stars: 5 },
    { name: "Marie D.", text: "Cadeau parfait pour l'anniversaire de mon golden retriever!", stars: 5 },
    { name: "Lucas P.", text: "Qualité exceptionnelle, j'ai commandé pour mes 3 chiens.", stars: 5 },
    { name: "Camille R.", text: "Le plus beau souvenir de mon chat disparu. Merci.", stars: 5 },
  ];

  const faqs = [
    { q: "Combien de photos puis-je inclure ?", a: "15 photos pour l'offre Basic, 30 pour Premium, et illimité pour Ultimate." },
    { q: "Combien de temps pour recevoir mon album ?", a: "Livraison en 48-72h après réception de vos photos et informations." },
    { q: "Mon album fonctionne sur téléphone ?", a: "Oui ! 100% responsive, optimisé mobile, tablette et ordinateur." },
    { q: "Puis-je modifier l'album après réception ?", a: "Oui, 1 modification gratuite dans les 7 jours après livraison." },
    { q: "Comment vous envoyez-vous mes photos ?", a: "Via un formulaire sécurisé que nous vous envoyons après paiement." },
    { q: "Puis-je ajouter une vidéo ?", a: "Oui, dans les offres Premium et Ultimate uniquement." },
    { q: "L'album est-il permanent ?", a: "Oui, hébergement gratuit à vie avec votre lien unique personnel." },
    { q: "Puis-je partager l'album avec ma famille ?", a: "Absolument ! Vous recevez un lien unique à partager librement." },
    { q: "Proposez-vous des albums pour animaux décédés ?", a: "Oui, notre offre Ultimate inclut une page hommage dédiée." },
    { q: "Puis-je commander un album cadeau ?", a: "Oui ! Parfait comme cadeau, nous pouvons personnaliser le message." },
  ];

  const MotionSection = motion.section;
  const MotionDiv = motion.div;
  const MotionH1 = motion.h1;
  const MotionP = motion.p;
  const MotionButton = motion.button;

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white">
      {/* HERO SECTION */}
      <MotionSection
        className="relative h-screen flex items-center justify-center overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-pink-400/30 via-purple-400/30 to-blue-400/30"></div>

        <MotionDiv
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=1200')" }}
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 20, repeat: Infinity }}
        />

        <div className="relative z-10 text-center px-4 max-w-4xl">
          <MotionDiv
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <Heart className="w-20 h-20 mx-auto mb-6 text-pink-500" />
          </MotionDiv>

          <MotionH1
            className="text-5xl md:text-7xl font-bold text-gray-800 mb-6"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            L'Album Interactif qui Célèbre<br />
            <span className="text-pink-500">Votre Amour à 4 Pattes</span>
          </MotionH1>

          <MotionP
            className="text-xl md:text-2xl text-gray-600 mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
          >
            Un héritage numérique émotionnel pour immortaliser chaque moment avec votre compagnon
          </MotionP>

          <MotionButton
            className="bg-pink-500 text-white px-10 py-5 rounded-full text-xl font-bold shadow-2xl hover:bg-pink-600 transform hover:scale-105 transition-all"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 1, type: "spring" }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            Créer Mon Album Maintenant
          </MotionButton>

          <p className="text-sm text-gray-500 mt-4">✨ Livraison en 48h • 100% Satisfait ou Remboursé</p>
        </div>

        <MotionDiv
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ChevronDown className="w-10 h-10 text-pink-500" />
        </MotionDiv>
      </MotionSection>

      {/* 3 ÉTAPES */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">De la Confusion à la Clarté</h2>
          <p className="text-xl text-center text-gray-600 mb-16">Comment ça marche ? Simple comme bonjour</p>

          <div className="grid md:grid-cols-3 gap-12">
            {[
              { num: "1", title: "Vous Commandez", desc: "Choisissez votre formule et payez en ligne en 2 minutes", icon: "🛒" },
              { num: "2", title: "Vous Envoyez", desc: "Uploadez vos photos et remplissez un formulaire simple (10 min)", icon: "📸" },
              { num: "3", title: "Vous Recevez", desc: "Votre album unique arrive en 48-72h par email avec votre lien privé", icon: "🎁" }
            ].map((step, i) => (
              <MotionDiv
                key={i}
                className="text-center p-8 rounded-2xl bg-gradient-to-br from-pink-50 to-purple-50 shadow-lg"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.2 }}
                viewport={{ once: true }}
              >
                <div className="text-6xl mb-4">{step.icon}</div>
                <div className="text-4xl font-bold text-pink-500 mb-3">Étape {step.num}</div>
                <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.desc}</p>
              </MotionDiv>
            ))}
          </div>
        </div>
      </section>

      {/* CE QUE VOUS OFFRE LE SYSTÈME */}
      <section className="py-20 px-4 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">Votre Album Interactif Inclut</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              "Galerie photo interactive avec zoom et animations",
              "Timeline chronologique des moments clés",
              "Compteur en temps réel (jours ensemble)",
              "Page personnalisée 'À propos' de votre animal",
              "Musique de fond (optionnelle et contrôlable)",
              "Design 100% responsive (mobile, tablette, PC)",
              "Hébergement gratuit à vie",
              "Lien unique privé à partager",
              "Animations fluides et professionnelles",
              "Téléchargement PDF inclus"
            ].map((feature, i) => (
              <MotionDiv
                key={i}
                className="flex items-start gap-4 bg-white p-6 rounded-xl shadow"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
              >
                <Check className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-lg">{feature}</span>
              </MotionDiv>
            ))}
          </div>
        </div>
      </section>

      {/* OFFRES */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">Choisissez Votre Formule</h2>
          <p className="text-xl text-center text-gray-600 mb-16">Concrètement, voici ce que vous recevez</p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "BASIC", price: "35€", photos: "15 photos", features: ["Timeline interactive", "Compteur temps réel", "Galerie animée", "Design responsive", "Hébergement à vie"] },
              { name: "PREMIUM", price: "65€", photos: "30 photos", features: ["Tout du Basic +", "2 vidéos incluses", "Musique personnalisée", "Mini-jeu Memory", "Support prioritaire"], popular: true },
              { name: "ULTIMATE", price: "120€", photos: "Illimité", features: ["Tout du Premium +", "Photos illimitées", "5 vidéos", "Page hommage", "Livre d'or virtuel"] }
            ].map((offer, i) => (
              <MotionDiv
                key={i}
                className={`relative p-8 rounded-2xl ${offer.popular ? 'bg-gradient-to-br from-pink-500 to-purple-500 text-white shadow-2xl scale-105' : 'bg-gray-50 border-2 border-gray-200'}`}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: offer.popular ? 1.05 : 1 }}
                transition={{ delay: i * 0.2 }}
                viewport={{ once: true }}
              >
                {offer.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-black px-4 py-1 rounded-full font-bold text-sm">
                    ⭐ POPULAIRE
                  </div>
                )}
                <h3 className="text-3xl font-bold mb-2">{offer.name}</h3>
                <div className="text-5xl font-bold mb-2">{offer.price}</div>
                <p className={`text-lg mb-6 ${offer.popular ? 'text-pink-100' : 'text-gray-600'}`}>{offer.photos}</p>
                <ul className="space-y-3 mb-8">
                  {offer.features.map((f, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <Check className="w-5 h-5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-4 rounded-full font-bold text-lg ${offer.popular ? 'bg-white text-pink-500' : 'bg-pink-500 text-white'} hover:opacity-90 transition`}>
                  Commander
                </button>
              </MotionDiv>
            ))}
          </div>
        </div>
      </section>

      {/* AVIS CLIENTS DÉFILANTS */}
      <section className="py-16 bg-gray-900 text-white overflow-hidden">
        <h2 className="text-4xl font-bold text-center mb-12">Ils Ont Adoré Leur Album</h2>
        <div className="relative">
          <MotionDiv
            className="flex gap-8"
            animate={{ x: [0, -1920] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          >
            {[...testimonials, ...testimonials, ...testimonials].map((t, i) => (
              <div key={i} className="flex-shrink-0 w-80 bg-white/10 backdrop-blur p-6 rounded-xl">
                <div className="flex mb-3">
                  {[...Array(t.stars)].map((_, j) => (
                    <Star key={j} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-lg mb-3">"{t.text}"</p>
                <p className="font-bold">— {t.name}</p>
              </div>
            ))}
          </MotionDiv>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">Questions Fréquentes</h2>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="border-2 border-gray-200 rounded-xl overflow-hidden">
                <button
                  className="w-full p-6 text-left font-bold text-lg flex justify-between items-center hover:bg-gray-50 transition"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  {faq.q}
                  <ChevronDown className={`w-6 h-6 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="p-6 pt-0 text-gray-600">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-20 px-4 bg-gradient-to-br from-pink-500 to-purple-600 text-white text-center">
        <h2 className="text-4xl md:text-6xl font-bold mb-6">Prêt à Immortaliser Votre Compagnon ?</h2>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">Rejoignez des centaines de propriétaires qui ont créé leur héritage numérique</p>
        <button className="bg-white text-pink-500 px-12 py-6 rounded-full text-2xl font-bold shadow-2xl hover:scale-105 transition-transform">
          Créer Mon Album Maintenant
        </button>
        <p className="text-sm mt-6 opacity-90">✨ Satisfaction garantie • Livraison 48h • Support 7j/7</p>
      </section>
    </div>
  );
}
```

---

Chemin: /src/PetMemoryApp.jsx

```jsx
import React, { useState } from 'react';
import { motion as Motion, AnimatePresence } from 'framer-motion';
import { Heart, Camera, Sparkles, Check, Star, ChevronDown, Upload, CreditCard, Mail, Download, Share2, Lock, CheckCircle, X } from 'lucide-react';

export default function PetMemoryApp() {
  const [page, setPage] = useState('landing');
  const [step, setStep] = useState(1);
  const [openFaq, setOpenFaq] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [form, setForm] = useState({ ownerName: '', ownerEmail: '', petName: '', package: 'premium' });

  const testimonials = [
    { name: "Sophie M.", text: "Album magnifique, j'ai pleuré ❤️", stars: 5 },
    { name: "Thomas L.", text: "Parfait pour ma Luna", stars: 5 },
    { name: "Marie D.", text: "Cadeau idéal !", stars: 5 },
  ];

  const faqs = [
    { q: "Combien de photos ?", a: "15 Basic, 30 Premium, illimité Ultimate" },
    { q: "Délai de livraison ?", a: "48-72h après paiement" },
    { q: "Compatible mobile ?", a: "Oui, 100% responsive" },
  ];

  const prices = { basic: 35, premium: 65, ultimate: 120 };

  if (page === 'landing') {
    return (
      <div className="min-h-screen bg-black text-white overflow-hidden">
        <Motion.section className="relative min-h-screen flex items-center justify-center overflow-hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="absolute inset-0 bg-gradient-to-br from-pink-600/30 via-purple-600/30 to-blue-600/30" />
          <Motion.div
            className="absolute inset-0 opacity-20"
            style={{ backgroundImage: "url('https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1600')", backgroundSize: 'cover' }}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 20, repeat: Infinity }}
          />

          {[...Array(3)].map((_, i) => (
            <Motion.div
              key={i}
              className="absolute rounded-full blur-3xl"
              style={{
                width: 300,
                height: 300,
                background: `radial-gradient(circle, ${['#ec4899', '#8b5cf6', '#3b82f6'][i]}40, transparent)`,
                left: `${i * 30}%`,
                top: `${i * 20}%`,
              }}
              animate={{ x: [0, 50, 0], y: [0, 30, 0] }}
              transition={{ duration: 15, repeat: Infinity }}
            />
          ))}

          <div className="relative z-10 text-center px-4 max-w-5xl">
            <Motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }} className="mb-8">
              <div className="inline-block p-6 rounded-full bg-gradient-to-br from-pink-500 to-purple-600"><Heart className="w-16 h-16" fill="white" /></div>
            </Motion.div>
            <Motion.h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 bg-clip-text text-transparent" initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
              L'Album Interactif<br/><span className="text-white">Qui Célèbre</span><br/>Votre Amour à 4 Pattes
            </Motion.h1>
            <Motion.p className="text-xl text-gray-300 mb-10" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
              Un héritage numérique émotionnel pour immortaliser votre compagnon
            </Motion.p>
            <Motion.button onClick={() => setPage('order')} className="px-12 py-6 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full text-xl font-bold" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.9 }}>
              <Sparkles className="inline w-6 h-6 mr-2" />Créer Mon Album<Sparkles className="inline w-6 h-6 ml-2" />
            </Motion.button>
          </div>
        </Motion.section>

        <section className="py-32 px-4 relative">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-20 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Simple</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[{ num: "01", title: "Commandez", icon: "🛒" }, { num: "02", title: "Envoyez", icon: "📸" }, { num: "03", title: "Recevez", icon: "🎁" }].map((s, i) => (
                <Motion.div key={i} className="group relative" initial={{ opacity: 0, y: 100 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.2 }}>
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-600/20 to-purple-600/20 rounded-3xl blur-xl" />
                  <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
                    <div className="text-8xl mb-6 opacity-50 font-black bg-gradient-to-br from-pink-500 to-purple-500 bg-clip-text text-transparent">{s.num}</div>
                    <div className="text-7xl mb-6">{s.icon}</div>
                    <h3 className="text-3xl font-bold">{s.title}</h3>
                  </div>
                </Motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-32 px-4">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-20 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Tarifs</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { name: "BASIC", price: "35€", features: ["15 photos", "Timeline", "Compteur"] },
                { name: "PREMIUM", price: "65€", features: ["30 photos", "Vidéos", "Musique"], popular: true },
                { name: "ULTIMATE", price: "120€", features: ["Illimité", "Hommage", "Livre d'or"] }
              ].map((o, i) => (
                <Motion.div key={i} className="relative" initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                  {o.popular && <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-6 py-2 rounded-full font-bold text-sm">⭐ POPULAIRE</div>}
                  <div className="bg-gradient-to-br from-pink-600 to-purple-600 rounded-3xl p-10 border-2 border-white/20">
                    <h3 className="text-3xl font-black mb-4">{o.name}</h3>
                    <div className="text-6xl font-black mb-4">{o.price}</div>
                    <ul className="space-y-4 mb-10">
                      {o.features.map((f, idx) => <li key={idx} className="flex items-center gap-2"><Check className="w-6 h-6" />{f}</li>)}
                    </ul>
                    <button onClick={() => setPage('order')} className="w-full py-5 rounded-full font-bold text-lg bg-white text-purple-600">Commander</button>
                  </div>
                </Motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 overflow-hidden">
          <h2 className="text-7xl font-black text-center mb-16">Avis</h2>
          <Motion.div className="flex gap-6" animate={{ x: ['0%', '-50%'] }} transition={{ duration: 30, repeat: Infinity, ease: "linear" }}>
            {[...testimonials, ...testimonials, ...testimonials].map((t, i) => (
              <div key={i} className="flex-shrink-0 w-96 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8">
                <div className="flex gap-1 mb-4">{[...Array(t.stars)].map((_, j) => <Star key={j} className="w-4 h-4 text-yellow-400" fill="currentColor" />)}</div>
                <p className="text-lg italic">"{t.text}"</p>
                <p className="font-bold mt-4">— {t.name}</p>
              </div>
            ))}
          </Motion.div>
        </section>

        <section className="py-32 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-7xl font-black text-center mb-16 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">FAQ</h2>
            {faqs.map((faq, i) => (
              <Motion.div key={i} className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl mb-4 overflow-hidden" initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
                <button className="w-full p-6 text-left font-bold text-lg flex justify-between" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {faq.q}
                  <ChevronDown className={`w-6 h-6 text-pink-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openFaq === i && (
                    <Motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-400">{faq.a}</Motion.div>
                  )}
                </AnimatePresence>
              </Motion.div>
            ))}
          </div>
        </section>

        <section className="py-32 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-600 via-purple-600 to-blue-600" />
          <div className="relative text-center">
            <h2 className="text-8xl font-black mb-8">Prêt ?</h2>
            <button onClick={() => setPage('order')} className="px-16 py-8 bg-white text-purple-600 rounded-full text-2xl font-black">
              <Sparkles className="inline w-8 h-8 mr-2" />Créer Maintenant<Sparkles className="inline w-8 h-8 ml-2" />
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <button onClick={() => setPage('landing')} className="mb-8 text-gray-400 hover:text-white">← Retour</button>

        <div className="mb-16 flex justify-between">
          {['Formule', 'Infos', 'Photos', 'Paiement', 'Confirmé'].map((s, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className={`w-14 h-14 rounded-full flex items-center justify-center font-bold border-2 ${step > i ? 'bg-green-500 border-green-400' : step === i + 1 ? 'bg-pink-500 border-pink-400' : 'bg-white/5 border-white/20'}`}>
                {step > i ? <Check className="w-6 h-6" /> : i + 1}
              </div>
              <span className="text-xs mt-3 text-gray-400">{s}</span>
            </div>
          ))}
        </div>

        {step === 1 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Choisissez</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {['basic', 'premium', 'ultimate'].map(pkg => (
                <div key={pkg} onClick={() => setForm({ ...form, package: pkg })} className={`cursor-pointer bg-white/5 backdrop-blur-xl border-2 ${form.package === pkg ? 'border-pink-400' : 'border-white/10'} rounded-2xl p-8`}>
                  <h3 className="text-2xl font-bold mb-3 uppercase">{pkg}</h3>
                  <div className="text-5xl font-black text-pink-400 mb-4">{prices[pkg]}€</div>
                </div>
              ))}
            </div>
            <button onClick={() => setStep(2)} className="w-full mt-12 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full text-xl font-bold">Continuer →</button>
          </Motion.div>
        )}

        {step === 2 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Infos</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10 space-y-6">
              <input type="text" placeholder="Votre nom" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl" value={form.ownerName} onChange={e => setForm({ ...form, ownerName: e.target.value })} />
              <input type="email" placeholder="Votre email" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl" value={form.ownerEmail} onChange={e => setForm({ ...form, ownerEmail: e.target.value })} />
              <input type="text" placeholder="Nom de votre animal ❤️" className="w-full p-5 bg-white/5 border-2 border-pink-400/50 rounded-xl text-2xl font-bold" value={form.petName} onChange={e => setForm({ ...form, petName: e.target.value })} />
            </div>
            <div className="flex gap-4 mt-10">
              <button onClick={() => setStep(1)} className="flex-1 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
              <button onClick={() => setStep(3)} className="flex-1 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-bold">Continuer →</button>
            </div>
          </Motion.div>
        )}

        {step === 3 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Photos</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
              <label className="flex flex-col items-center border-4 border-dashed border-pink-400/30 rounded-2xl p-16 cursor-pointer hover:border-pink-400">
                <Upload className="w-20 h-20 text-pink-400 mb-6" />
                <span className="text-2xl font-bold">Ajoutez vos photos</span>
                <input type="file" multiple accept="image/*" onChange={(e) => setPhotos(Array.from(e.target.files))} className="hidden" />
              </label>
              {photos.length > 0 && <p className="mt-6 text-xl font-bold">{photos.length} photo(s)</p>}
            </div>
            <div className="flex gap-4 mt-10">
              <button onClick={() => setStep(2)} className="flex-1 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
              <button onClick={() => setStep(4)} disabled={photos.length === 0} className="flex-1 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-bold disabled:opacity-30">Continuer →</button>
            </div>
          </Motion.div>
        )}

        {step === 4 && (
          <Motion.div initial={{ opacity: 0, x: 100 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-5xl font-black text-center mb-12 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Paiement</h2>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
              <div className="bg-white/5 rounded-2xl p-6 mb-6">
                <div className="flex justify-between text-3xl font-black"><span>TOTAL</span><span className="text-pink-400">{prices[form.package]}€</span></div>
              </div>
              <input type="text" placeholder="Numéro de carte" className="w-full p-5 bg-white/5 border border-white/10 rounded-xl mb-4" />
              <button onClick={() => setStep(5)} className="w-full py-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full text-xl font-bold flex items-center justify-center gap-3">
                <CreditCard className="w-6 h-6" />Payer {prices[form.package]}€
              </button>
            </div>
            <button onClick={() => setStep(3)} className="w-full mt-6 py-5 bg-white/5 rounded-full font-bold">← Retour</button>
          </Motion.div>
        )}

        {step === 5 && (
          <Motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center">
            <div className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 backdrop-blur-xl border border-green-400/30 rounded-3xl p-16">
              <CheckCircle className="w-32 h-32 text-green-400 mx-auto mb-8" />
              <h2 className="text-6xl font-black mb-6 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">Validé ! 🎉</h2>
              <p className="text-2xl mb-4">Album pour <span className="font-bold text-pink-400">{form.petName}</span></p>
              <p className="text-5xl font-black text-green-400 mb-12">48-72h</p>
              <div className="flex gap-4">
                <button className="flex-1 py-5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full font-bold flex items-center justify-center gap-3"><Download className="w-5 h-5" />Reçu</button>
                <button className="flex-1 py-5 bg-gradient-to-r from-purple-500 to-blue-600 rounded-full font-bold flex items-center justify-center gap-3"><Share2 className="w-5 h-5" />Partager</button>
              </div>
            </div>
          </Motion.div>
        )}
      </div>
    </div>
  );
}
```

---

Fichiers non inclus dans ce document:
- /public/vite.svg
- /src/assets/react.svg
- /package-lock.json

