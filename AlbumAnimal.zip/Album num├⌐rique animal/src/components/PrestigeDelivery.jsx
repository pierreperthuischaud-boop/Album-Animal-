import React from 'react';
import { motion } from 'framer-motion';
import { Award, Shield, CheckCircle2, Image as ImageIcon, Crown, Star, ChevronRight, BookOpen, PackagePlus } from 'lucide-react';

export default function PrestigeDelivery() {
  const fade = { initial: { opacity: 0, y: 20 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true } };
  const MotionDiv = motion.div;
  return (
    <section id="ce-que-nous-livrons" className="bg-[#0e0f13] text-[#F8F6F0]">
      <div className="max-w-6xl mx-auto px-4 py-24">
        <MotionDiv {...fade} className="text-center max-w-4xl mx-auto">
          <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80 mb-3">Prestige Animalier</div>
          <h2 className="font-black leading-tight text-4xl md:text-6xl text-white">L’Expérience Prestige Animalier Dévoilée</h2>
          <p className="mt-4 text-lg md:text-xl text-[#e9e4d6]">Vous recevez un album numérique premium, prêt à partager, qui immortalise l’âme de votre compagnon. Livraison en 3 jours max après validation, hébergement privé et lien sécurisé compris.</p>
        </MotionDiv>

        <div className="mt-16 grid md:grid-cols-2 gap-10 items-start">
          <motion.div {...fade} className="rounded-3xl p-8 border border-[#1E2761]/30 bg-[#11131a]">
            <div className="flex items-center gap-3 mb-6">
              <Crown className="w-6 h-6 text-[#D4AF37]" />
              <div className="text-2xl font-bold text-white">L’Album Numérique d’Exception</div>
            </div>
            <div className="space-y-4 text-[#e9e4d6]">
              <p>Livrables concrets : un PDF HD optimisé pour impression, un lecteur feuilletable web privé (mot de passe possible), un lien de partage sécurisé, et une version écran 1920x1080 pour consultation fluide sur mobile, tablette et TV.</p>
              <p>Contenu : 25-35 pages numériques composées de 4 histoires personnalisées, 10 créations artistiques, 4 trophées et une biographie émotionnelle. Mise en page cinématographique, animations subtiles et navigation fluide.</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-xl bg-white/5 border border-white/10 p-4">
                  <div className="font-semibold text-white">Formats livrés</div>
                  <ul className="mt-2 space-y-1">
                    <li>• PDF HD (impression)</li>
                    <li>• Lecteur web privé</li>
                    <li>• Lien partage sécurisé</li>
                    <li>• Version écran 1920x1080</li>
                    <li>• Export images clés</li>
                  </ul>
                </div>
                <div className="rounded-xl bg-white/5 border border-white/10 p-4">
                  <div className="font-semibold text-white">Expérience de livraison</div>
                  <ul className="mt-2 space-y-1">
                    <li>• Délai : 3 jours max</li>
                    <li>• Accès par lien privé</li>
                    <li>• Guide d’impression PDF</li>
                    <li>• Support si besoin</li>
                    <li>• Mises à jour possibles</li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
          <motion.div {...fade} className="rounded-3xl p-0 overflow-hidden border border-[#1E2761]/30 bg-gradient-to-br from-[#1E2761] to-[#0e0f13]">
            <div className="relative aspect-[4/3]">
              <img src="https://picsum.photos/id/1025/1600/1000" alt="Chien heureux – exemple artistique" className="w-full h-full object-cover opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-2 text-[#D4AF37]">
                  <Star className="w-5 h-5" /><Star className="w-5 h-5" /><Star className="w-5 h-5" /><Star className="w-5 h-5" /><Star className="w-5 h-5" />
                </div>
                <div className="mt-2 text-sm text-[#F8F6F0]/90">Exemple de rendu artistique – album numérique prêt à partager.</div>
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-3 text-[#e9e4d6]">
                <ImageIcon className="w-5 h-5 text-[#D4AF37]" />
                <span>Visuels hautes définitions optimisés pour écran et impression.</span>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div {...fade} className="mt-20">
          <div className="text-center mb-8">
            <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80">Processus</div>
            <h3 className="text-3xl md:text-4xl font-black text-white">Comment nous créons votre chef-d'oeuvre</h3>
            <div className="text-[#e9e4d6] mt-2">Exemple fil rouge : Rexou, Golden Retriever de 3 ans, personnalité gourmande et aventurière.</div>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                t: 'Le Formulaire Magique',
                d: "Vous partagez nom, race, âge, traits dominants, souvenirs marquants, photos favorites, activités et lieux préférés, puis choisissez un thème narratif. Pour Rexou : Gourmand + Aventurier, plage de Deauville, scène du croissant dérobé, esprit joueur.",
                i: <BookOpen className='w-6 h-6 text-[#D4AF37]' />
              },
              {
                t: 'Analyse IA + Artistes',
                d: "Notre IA de pointe établit un profil héroïque et propose palettes, ambiances et archétypes visuels. Rexou devient « Le Grand Explorateur Gourmand ». Univers : Indiana Jones meets monde fantastique, ors chauds, verts jungle, touches bleu aventure.",
                i: <Star className='w-6 h-6 text-[#D4AF37]' />
              },
              {
                t: 'Transformation Photo',
                d: "Chaque image est détourée, intégrée dans des décors 3D, re-lumière et color grading cinématographique. Exemple : Rexou sur la plage devient « le Temple de l’Os Éternel », palmiers dorés, crépuscule mystique, lueurs secrètes. 25-35 compositions uniques.",
                i: <ImageIcon className='w-6 h-6 text-[#D4AF37]' />
              },
              {
                t: 'Écriture & Design',
                d: "Rédaction épique sur-mesure (ton cinématographique, humour élégant). Mise en page agence : doubles pages spectaculaires, galeries stylisées, cartes de l’univers. Validation PDF, deux allers-retours inclus, impression premium, livraison prestigieuse.",
                i: <PackagePlus className='w-6 h-6 text-[#D4AF37]' />
              },
            ].map((step, idx) => (
              <motion.div key={idx} {...fade} className="rounded-2xl p-6 border border-white/10 bg-white/5">
                <div className="flex items-center gap-3 mb-2">
                  {step.i}
                  <div className="font-bold text-white">{`Étape ${idx + 1} : ${step.t}`}</div>
                </div>
                <div className="text-sm text-[#e9e4d6]">{step.d}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div {...fade} className="mt-20">
          <div className="text-center mb-10">
            <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80">Exemples de pages</div>
            <h3 className="text-3xl md:text-4xl font-black text-white">A l’intérieur de l’album</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Couverture & Page de Titre</div>
              <p className="text-sm text-[#e9e4d6]">Couverture noire mate, titre doré gravé : « REXOU – L’EXPLORATEUR DES MONDES OUBLIÉS ». Portrait héroïque, lumière dramatique, jungle mystique en arrière-plan. Première page intérieure noire, sentence dorée, pleine page suivante façon affiche de film.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Double Page Narrative Illustrée</div>
              <p className="text-sm text-[#e9e4d6]">Gauche : texte sur parchemin doré, « Chronique I : La Jungle de Salon ». Droite : jungle 3D luxuriante, temple ancien, papillons lumineux, rendu 8K. Rexou, regard déterminé, atmosphère d’aventure.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Galerie « Dossier Secret »</div>
              <p className="text-sm text-[#e9e4d6]">Dossier classifié, tampons « CONFIDENTIEL ». Photos noir-et-blanc contrastées, cadres Polaroid annotés : « miettes de croissant », « suspect près du réfrigérateur ». Fond papier vieilli, taches de café, ambiance film noir.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Double Page Épique</div>
              <p className="text-sm text-[#e9e4d6]">Rexou en course sur la plage : désert doré, nuages dramatiques roses/oranges/violets, vagues stylisées, particules de lumière, composition « golden ratio », color grading cinéma.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Statistiques & Profil Héros</div>
              <p className="text-sm text-[#e9e4d6]">Fiche façon RPG : barres de courage, gourmandise, vitesse, câlin, intelligence. Portrait pop-art, pouvoirs spéciaux : « Flair Légendaire ». Style gaming moderne.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-1">Timeline « Grandes Aventures »</div>
              <p className="text-sm text-[#e9e4d6]">Frise sur double page, carte parchemin, jalons de 2021 à 2024 : arrivée du héros, bataille du croissant, conquête de Deauville, gardien de la maison. Liens dorés, mini-photos détourées.</p>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5 md:col-span-2">
              <div className="font-bold text-white mb-1">Page Finale « Vers l’Infini »</div>
              <p className="text-sm text-[#e9e4d6]">Double page noire, Rexou au centre dans un cosmos étoilé. Nébuleuses bleues et violettes, planètes lointaines, trainées lumineuses. Texte doré : « Son voyage ne fait que commencer… » Atmosphère Interstellar.</p>
            </div>
          </div>
        </motion.div>

        <motion.div {...fade} className="mt-20">
          <div className="text-center mb-10">
            <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80">Pourquoi c’est différent</div>
            <h3 className="text-3xl md:text-4xl font-black text-white">Au-dela d’un album classique</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="rounded-2xl p-6 border border-white/10 bg-[#151821]">
              <div className="font-bold text-white mb-2">Ce que vous ne recevrez pas</div>
              <ul className="text-sm text-[#e9e4d6] space-y-2">
                <li>❌ Mise en page automatique</li>
                <li>❌ Photos brutes collées</li>
                <li>❌ Templates génériques</li>
                <li>❌ Textes passe-partout</li>
                <li>❌ Qualité d’impression standard</li>
                <li>❌ Délai éclair sans personnalisation</li>
                <li>❌ PDF à imprimer soi-même</li>
              </ul>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-white mb-2">Ce que vous recevez</div>
              <ul className="text-sm text-[#e9e4d6] space-y-2">
                <li>✅ 25-35 compositions artistiques uniques</li>
                <li>✅ Fusion IA + artistes + rédacteurs</li>
                <li>✅ Univers narratif 100% personnalisé</li>
                <li>✅ 2 000-4 000 mots de textes épique</li>
                <li>✅ Album physique qualité muséale</li>
                <li>✅ Résolution 8K</li>
                <li>✅ 3-4 semaines de création artisanale</li>
                <li>✅ Oeuvre d’art à conserver 100+ ans</li>
              </ul>
            </div>
          </div>
        </motion.div>

        <motion.div {...fade} className="mt-20">
          <div className="text-center mb-10">
            <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80">Personnalisation réelle</div>
            <h3 className="text-3xl md:text-4xl font-black text-white">Quand la personnalité change tout</h3>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                n: 'Rexou',
                  d: 'Gourmand + Aventurier. Univers : jungle d’aventure, temples de friandises. Palette : ors, verts jungle, touches caramel. Scènes : trésor culinaire, temple de l’os éternel, forêt de saucisses géantes. Style : Indiana Jones meets Willy Wonka.',
                img: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?q=80&w=1200&auto=format&fit=crop'
              },
              {
                n: 'Luna',
                  d: 'Protectrice + Sage. Univers : montagnes sacrées, temples zen, aurores boréales. Palette : bleus profonds, blancs purs, violets mystiques. Scènes : gardienne du Temple de la Paix, méditation au sommet, protectrice des rêves. Style : Avatar meets Ghibli.',
                img: 'https://images.unsplash.com/photo-1561037404-61cd46aa615b?q=80&w=1200&auto=format&fit=crop'
              },
              {
                n: 'Max',
                  d: 'Têtu + Joueur. Univers : arènes modernes, stades épiques. Palette : rouges énergiques, noirs puissants, jaunes éclair. Scènes : champion de l’arène, courses légendaires, défis impossibles. Style : sports épiques meets Marvel.',
                img: 'https://images.unsplash.com/photo-1517423440428-a5a00ad493e8?q=80&w=1200&auto=format&fit=crop'
              },
              {
                n: 'Mimi',
                  d: 'Câline + Mystérieuse. Univers : Paris nocturne, rooftops romantiques. Palette : noirs élégants, roses poudrés, ors vintage. Scènes : espionne secrète, gardienne des nuits, détective du cœur. Style : film noir meets romance parisienne.',
                img: 'https://images.unsplash.com/photo-1519052537078-e6302a4968d4?q=80&w=1200&auto=format&fit=crop'
              },
            ].map((c, i) => (
              <motion.div key={i} {...fade} className="rounded-2xl overflow-hidden border border-white/10 bg-white/5">
                <div className="aspect-[4/3] overflow-hidden">
                  <img src={c.img} alt={c.n} className="w-full h-full object-cover hover:scale-[1.03] transition-transform" />
                </div>
                <div className="p-5">
                  <div className="text-white font-bold text-lg mb-1">{c.n}</div>
                  <div className="text-sm text-[#e9e4d6]">{c.d}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div {...fade} className="mt-20">
          <div className="text-center mb-10">
            <div className="text-xs tracking-widest uppercase text-[#D4AF37]/80">Garanties</div>
            <h3 className="text-3xl md:text-4xl font-black text-white">Nos engagements</h3>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="flex items-center gap-2 mb-2 text-[#D4AF37]"><Shield className="w-5 h-5" /><span className="font-semibold text-white">Unicité absolue</span></div>
                <div className="text-sm text-[#e9e4d6]">Chaque album est original, sans template. Si un album identique au vôtre existe, remboursement integral.</div>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="flex items-center gap-2 mb-2 text-[#D4AF37]"><CheckCircle2 className="w-5 h-5" /><span className="font-semibold text-white">Satisfaction totale</span></div>
                <div className="text-sm text-[#e9e4d6]">Deux rounds de modifications inclus. Solde du uniquement apres validation du PDF final.</div>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="flex items-center gap-2 mb-2 text-[#D4AF37]"><Award className="w-5 h-5" /><span className="font-semibold text-white">Qualité muséale</span></div>
                <div className="text-sm text-[#e9e4d6]">Papier, impression et reliure professionnels. Conservation garantie 100+ ans. Certification ISO sur demande.</div>
            </div>
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="flex items-center gap-2 mb-2 text-[#D4AF37]"><Star className="w-5 h-5" /><span className="font-semibold text-white">Délai & prestige</span></div>
                <div className="text-sm text-[#e9e4d6]">Livraison en 3 jours max après validation. Si l’effet « Wow » n’est pas au rendez-vous, nous recommençons.</div>
            </div>
          </div>
        </motion.div>

        <motion.div {...fade} className="mt-20 text-center">
          <div className="text-[#e9e4d6] max-w-3xl mx-auto text-lg">Maintenant que vous savez exactement ce que vous allez recevoir, vous vous demandez peut-être : « Est-ce vraiment pour moi ? Par où commencer ? Comment être sûr du résultat ? » Nous avons simplifié le parcours en trois étapes ultra-claires.</div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <a href="#temoignages" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white/10 hover:bg-white/15 transition font-semibold">Voir des exemples complets <ChevronRight className="w-4 h-4" /></a>
            <a href="#ce-que-nous-livrons" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white/10 hover:bg-white/15 transition font-semibold">Découvrir les univers</a>
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSfSKDA_ZWoBCn-5lpx5z5Jt6AScqkPYZhHWmBYTsR80mH85YA/viewform?usp=dialog" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#D4AF37] text-black font-bold hover:brightness-110 transition">Créer l’Album de Mon Animal</a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
