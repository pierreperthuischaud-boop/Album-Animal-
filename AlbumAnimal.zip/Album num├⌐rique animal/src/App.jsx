import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ChevronDown, Search, Image as ImageIcon, Palette, FileText, Heart, Camera, BookOpen, Award } from 'lucide-react';
import PrestigeDelivery from './components/PrestigeDelivery.jsx';

export default function App() {
  const [page, setPage] = useState('home');
  const [openFaq, setOpenFaq] = useState(null);
  const [quizIndex, setQuizIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [photoItems, setPhotoItems] = useState([]);
  const [videoItems, setVideoItems] = useState([]);
  const [cloudName, setCloudName] = useState('');
  const [uploadPreset, setUploadPreset] = useState('');
  const [uploading, setUploading] = useState(false);
  const [photoUrls, setPhotoUrls] = useState([]);
  const [videoUrls, setVideoUrls] = useState([]);
  const [formBaseUrl, setFormBaseUrl] = useState('');
  const [formMappingText, setFormMappingText] = useState('{\n  "petName": "",\n  "petType": "",\n  "petBreed": "",\n  "personality": "",\n  "bestMemory": "",\n  "activities": "",\n  "style": "",\n  "timeline": "",\n  "counter": "",\n  "delivery": "",\n  "deliveryName": "",\n  "deliveryEmail": "",\n  "photos_urls": "",\n  "videos_urls": ""\n}');
  const [openCh, setOpenCh] = useState(null);
  const questions = [
    { id: 'petName', label: "Prénom de votre compagnon", type: 'text', required: true },
    { id: 'petType', label: "Type d’animal", type: 'cards', options: ['🐕 Chien', '🐱 Chat', '🐾 Autre'], required: true },
    { id: 'petBreed', label: "Race ou type", type: 'text', required: false },
    { id: 'ageYears', label: "Âge (années)", type: 'range', min: 0, max: 20, required: false },
    { id: 'birthDate', label: "Date de naissance (si connue)", type: 'date', required: false },
    { id: 'adoptionDate', label: "Date d’adoption/accueil", type: 'date', required: true },
    { id: 'isAlive', label: "Est-il toujours avec vous ?", type: 'radio', options: ['Oui, heureusement !', 'Non, il nous a quitté'], required: true },
    { id: 'otherDates', label: "Autres dates importantes", type: 'textarea', max: 300, required: false },
    { id: 'personality', label: "Personnalité en quelques mots", type: 'textarea', min: 50, max: 500, required: true },
    { id: 'bestMemory', label: "Votre plus beau souvenir", type: 'textarea', min: 100, max: 800, required: true },
    { id: 'habits', label: "Habitudes amusantes", type: 'textarea', max: 300, required: false },
    { id: 'activities', label: "Activités préférées", type: 'activities', options: ['🎾 Balles', '🧸 Peluches', '🦴 Friandises', '🚶 Promenades', '🏊 Nage', '🐕 Socialiser', '💤 Câlins', '📺 TV'], required: false },
    { id: 'unique', label: "Quelque chose d’unique à son sujet", type: 'text', required: false },
    { id: 'photos', label: "Uploadez vos photos", type: 'photos', required: true },
    { id: 'videos', label: "Uploadez vos vidéos (optionnel)", type: 'videos', required: false },
    { id: 'style', label: "Ambiance visuelle", type: 'style', options: ['Classique Élégant', 'Moderne Coloré', 'Nostalgique Sépia'], required: true },
    { id: 'timeline', label: "Timeline détaillée ?", type: 'radio', options: ['Oui', 'Non'], required: true },
    { id: 'counter', label: "Compteur temps réel ?", type: 'radio', options: ['Oui', 'Non'], required: true },
    { id: 'extras', label: "Fonctionnalités bonus", type: 'checkbox', options: ['Musique', 'Diaporama', 'Page hommage', 'Livre d’or', 'PDF', 'Mot de passe'], required: false },
    { id: 'delivery', label: "Livraison", type: 'cards', options: ['⚡ Express 48h', '📦 Standard 72-96h'], required: true },
  ];

  if (page === 'home') {
    const MotionDiv = motion.div;
    return (
      <div className="bg-black text-white">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <img
            src="https://picsum.photos/id/237/2000/1200"
            alt="Chien heureux sur fond lumineux"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/80" />
          <div className="absolute -top-20 -left-20 w-[36rem] h-[36rem] rounded-full bg-pink-500/20 blur-3xl" />
          <div className="absolute -bottom-28 -right-28 w-[40rem] h-[40rem] rounded-full bg-violet-500/20 blur-3xl" />

          <div className="relative z-10 text-center px-6 max-w-5xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 text-sm text-white/90 mb-4">
              <span>Album numérique premium</span>
              <span className="inline-block w-1 h-1 rounded-full bg-yellow-400" />
              <span>Livraison en 3 jours max</span>
            </div>
            <motion.h1 initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-5xl md:text-7xl font-black mb-4 text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.35)]">
              Transformez les souvenirs de votre animal en un album premium unique 🐾
            </motion.h1>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="text-base md:text-lg text-gray-200 max-w-3xl mx-auto">
              4 histoires personnalisées, 10 créations artistiques, une salle des trophées et une biographie émotionnelle.
            </motion.p>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="text-base md:text-lg text-gray-200 mb-8 max-w-3xl mx-auto">
              Un vrai livre‑mémoire numérique qui immortalise votre lien unique avec votre compagnon.
            </motion.p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href="https://docs.google.com/forms/d/e/1FAIpQLSfSKDA_ZWoBCn-5lpx5z5Jt6AScqkPYZhHWmBYTsR80mH85YA/viewform?usp=dialog"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 rounded-full text-lg font-bold bg-yellow-400 text-black shadow-[0_10px_40px_rgba(251,191,36,0.35)] hover:shadow-[0_12px_46px_rgba(251,191,36,0.5)] transition"
              >
                Lancer la création de mon album
              </a>
              <a
                href="#temoignages"
                className="px-6 py-4 rounded-full text-lg font-semibold bg-white/10 border border-white/15 text-white hover:bg-white/15 transition"
              >
                Voir des exemples
              </a>
            </div>
            <div className="mt-4 text-sm text-gray-200">Paiement sécurisé • Livraison 3 jours max • Satisfaction garantie 💯</div>
            <div className="mt-5 text-gray-200 max-w-3xl mx-auto">
              Plus qu’un simple diaporama : un album numérique immersif avec narration, créations artistiques et trophées exclusifs, prêt à partager.
            </div>
            <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-3 text-white/90">
              <div className="flex items-center justify-center gap-2 text-sm bg-white/10 rounded-xl py-3 border border-white/10"><BookOpen className="w-5 h-5" /> Histoires</div>
              <div className="flex items-center justify-center gap-2 text-sm bg-white/10 rounded-xl py-3 border border-white/10"><Palette className="w-5 h-5" /> Créations artistiques</div>
              <div className="flex items-center justify-center gap-2 text-sm bg-white/10 rounded-xl py-3 border border-white/10"><Award className="w-5 h-5" /> Trophées</div>
              <div className="flex items-center justify-center gap-2 text-sm bg-white/10 rounded-xl py-3 border border-white/10"><ImageIcon className="w-5 h-5" /> Galerie illimitée</div>
              <div className="flex items-center justify-center gap-2 text-sm bg-white/10 rounded-xl py-3 border border-white/10"><Heart className="w-5 h-5" /> Biographie émotionnelle</div>
            </div>
          </div>
        </section>

        <PrestigeDelivery />
        <section id="clarte" className="py-20 px-4" style={{ background: 'linear-gradient(135deg, #1a1a2e, #16213e 50%, #0f3460)' }}>
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-black text-center mb-2 text-white">De la Confusion à la Clarté en 3 Étapes</h2>
            <p className="text-center text-gray-300 mb-12">Votre parcours vers un album personnalisé unique : simple, guidé et magique</p>
            <div className="grid md:grid-cols-3 gap-10">
              <div className="rounded-3xl p-10 border" style={{ borderColor: 'rgba(168,85,247,0.2)', background: 'linear-gradient(180deg, #1e293b, #0f172a)' }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="text-6xl font-extrabold" style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>1</div>
                  <div className="text-pink-400 font-bold text-xl">Explorez notre galerie d’inspiration</div>
                </div>
                <div className="rounded-2xl p-6 mb-6" style={{ background: '#0f2142' }}>
                  <div className="flex items-center justify-center gap-4 text-3xl">
                    <span className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center">🖼️</span>
                    <span className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center">📖</span>
                    <span className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center">✨</span>
                  </div>
                  <div className="text-center text-gray-300 mt-3 text-sm">Découvrez des exemples d’albums créés</div>
                </div>
                <a href="#temoignages" className="inline-block px-6 py-3 rounded-xl font-semibold transition"
                   style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', boxShadow: '0 6px 24px rgba(168,85,247,0.35)' }}>
                  Voir la galerie →
                </a>
                <p className="text-gray-300 text-sm mt-4">
                  Plongez dans notre univers d’albums personnalisés. Photomontages artistiques, aventures narratives, salle des trophées… Laissez‑vous inspirer pour imaginer l’album unique de votre compagnon.
                </p>
              </div>

              <div className="rounded-3xl p-10 border" style={{ borderColor: 'rgba(168,85,247,0.2)', background: 'linear-gradient(180deg, #1e293b, #0f172a)' }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="text-6xl font-extrabold" style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>2</div>
                  <div className="text-pink-400 font-bold text-xl">Racontez l’histoire de votre animal</div>
                </div>
                <div className="rounded-2xl p-6 mb-6" style={{ background: '#0f2142' }}>
                  <div className="flex items-center justify-center gap-3 mb-3">
                    <span className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center text-3xl">✍️</span>
                    <div className="text-white font-semibold">Formulaire personnalisé</div>
                  </div>
                  <div className="grid gap-2 text-xs text-gray-300">
                    <div className="rounded-lg bg-white/5 px-3 py-2">Prénom de l’animal</div>
                    <div className="rounded-lg bg-white/5 px-3 py-2">Traits de personnalité</div>
                    <div className="rounded-lg bg-white/5 px-3 py-2">Moments inoubliables</div>
                    <div className="rounded-lg bg-white/5 px-3 py-2">📸 Ajouter vos photos</div>
                  </div>
                </div>
                <a href="https://docs.google.com/forms/d/e/1FAIpQLSfSKDA_ZWoBCn-5lpx5z5Jt6AScqkPYZhHWmBYTsR80mH85YA/viewform?usp=dialog" target="_blank" rel="noopener noreferrer"
                   className="inline-block px-6 py-3 rounded-xl font-semibold transition"
                   style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', boxShadow: '0 6px 24px rgba(168,85,247,0.35)' }}>
                  Remplir le formulaire →
                </a>
                <p className="text-gray-300 text-sm mt-4">
                  Partagez son prénom, ses lieux favoris, ses petits moments qui vous font sourire, son tempérament unique. Téléchargez vos plus belles photos: nous les transformerons en œuvres d’art.
                </p>
              </div>

              <div className="rounded-3xl p-10 border" style={{ borderColor: 'rgba(168,85,247,0.2)', background: 'linear-gradient(180deg, #1e293b, #0f172a)' }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="text-6xl font-extrabold" style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>3</div>
                  <div className="text-pink-400 font-bold text-xl">Recevez votre album en 1 clic</div>
                </div>
                <div className="rounded-2xl p-6 mb-6 flex flex-col items-center gap-3" style={{ background: '#0f2142' }}>
                  <div className="w-20 h-20 rounded-full" style={{ background: 'linear-gradient(135deg, #8B5CF6, #EC4899)' }} />
                  <div className="text-4xl">✓</div>
                  <div className="text-gray-200 text-sm flex items-center gap-2">📖 Album prêt à télécharger</div>
                </div>
                <span className="inline-block px-6 py-3 rounded-xl font-semibold"
                      style={{ background: 'linear-gradient(90deg, #a855f7, #ec4899)', boxShadow: '0 6px 24px rgba(168,85,247,0.35)', opacity: 0.7 }}>
                  Album généré avec succès
                </span>
                <p className="text-gray-300 text-sm mt-4">
                  10 photomontages professionnels, 4 aventures narratives, une salle des trophées unique, décorations contextuelles. Votre album de 25–35 pages est prêt. Téléchargez le PDF premium en quelques secondes.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 px-4" style={{ backgroundColor: '#f5f5f2' }}>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-4xl md:text-5xl font-black text-black">Votre Album Numérique Premium : Un Trésor en 5 Chapitres</h2>
              <p className="text-gray-700 mt-2 italic">Bien plus qu'une simple galerie photo : une œuvre narrative et artistique complète</p>
            </div>
            <div className="space-y-3">
              <div className="rounded-2xl bg-white border border-gray-200">
                <button onClick={() => setOpenCh(openCh === 0 ? null : 0)} className="w-full text-left p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#8B5CF6]/15 flex items-center justify-center"><Palette className="w-6 h-6" color="#8B5CF6" /></div>
                    <div>
                      <div className="text-lg font-bold text-black">Chapitre 1 : Les Aventures Narratives</div>
                      <div className="text-sm text-gray-600">4 histoires personnalisées façon conte illustré</div>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-gray-500 transition ${openCh === 0 ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openCh === 0 && (
                    <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-700">
                      Des récits sensibles qui se devinent plus qu’ils ne se dévoilent. Une narration délicate, pensée pour préserver la surprise.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="rounded-2xl bg-white border border-gray-200">
                <button onClick={() => setOpenCh(openCh === 1 ? null : 1)} className="w-full text-left p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#EC4899]/15 flex items-center justify-center"><Camera className="w-6 h-6" color="#EC4899" /></div>
                    <div>
                      <div className="text-lg font-bold text-black">Chapitre 2 : Le Studio Artistique</div>
                      <div className="text-sm text-gray-600">10 transformations créatives de vos photos</div>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-gray-500 transition ${openCh === 1 ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openCh === 1 && (
                    <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-700">
                      Des interprétations artistiques sur‑mesure, subtiles et élégantes, qui magnifient sans jamais tout révéler.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="rounded-2xl bg-white border border-gray-200">
                <button onClick={() => setOpenCh(openCh === 2 ? null : 2)} className="w-full text-left p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#FB923C]/15 flex items-center justify-center"><Award className="w-6 h-6" color="#FB923C" /></div>
                    <div>
                      <div className="text-lg font-bold text-black">Chapitre 3 : La Salle des Trophées</div>
                      <div className="text-sm text-gray-600">4 distinctions honorifiques personnalisées</div>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-gray-500 transition ${openCh === 2 ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openCh === 2 && (
                    <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-700">
                      Des distinctions raffinées qui célèbrent l’âme de votre compagnon, avec tact et sobriété.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="rounded-2xl bg-white border border-gray-200">
                <button onClick={() => setOpenCh(openCh === 3 ? null : 3)} className="w-full text-left p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#3B82F6]/15 flex items-center justify-center"><ImageIcon className="w-6 h-6" color="#3B82F6" /></div>
                    <div>
                      <div className="text-lg font-bold text-black">Chapitre 4 : La Galerie de Souvenirs</div>
                      <div className="text-sm text-gray-600">Photos illimitées sublimées + 6 versions artistiques</div>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-gray-500 transition ${openCh === 3 ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openCh === 3 && (
                    <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-700">
                      Une mise en lumière délicate de vos images, pour un écrin visuel qui suggère sans dévoiler.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="rounded-2xl bg-white border border-gray-200">
                <button onClick={() => setOpenCh(openCh === 4 ? null : 4)} className="w-full text-left p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#EF4444]/15 flex items-center justify-center"><Heart className="w-6 h-6" color="#EF4444" /></div>
                    <div>
                      <div className="text-lg font-bold text-black">Chapitre 5 : Le Livre‑Mémoire Émotionnel</div>
                      <div className="text-sm text-gray-600">L’histoire complète de votre lien unique</div>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-gray-500 transition ${openCh === 4 ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openCh === 4 && (
                    <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-6 pb-6 text-gray-700">
                      Un portrait sensible de votre histoire, écrit avec pudeur pour laisser l’émotion faire son chemin.
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="mt-8 rounded-2xl bg-white border border-gray-200 p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <div className="font-bold text-black mb-1">Ce que vous recevez au final :</div>
                  <ul className="text-sm text-gray-800 space-y-1">
                    <li>✅ 4 aventures narratives sur mesure</li>
                    <li>✅ 10 créations artistiques pro</li>
                    <li>✅ 4 trophées de reconnaissance</li>
                    <li>✅ Galerie photo illimitée sublimée</li>
                    <li>✅ Biographie émotionnelle complète</li>
                  </ul>
                  <div className="text-sm text-gray-700 mt-2">= Un album de 25–35 pages minimum, richement illustré et 100% unique</div>
                </div>
                <div className="text-center md:text-right">
                  <a href="https://docs.google.com/forms/d/e/1FAIpQLSfSKDA_ZWoBCn-5lpx5z5Jt6AScqkPYZhHWmBYTsR80mH85YA/viewform?usp=dialog" target="_blank" rel="noopener noreferrer"
                     className="inline-block px-6 py-4 bg-red-600 text-white rounded-full font-bold hover:bg-red-700 transition mt-2 md:mt-0">
                    Je veux mon album personnalisé →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 px-4" style={{ backgroundColor: '#1f2430' }}>
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-black text-center mb-14 text-white">Comment Ça Marche ?</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { t: 'Répondez à 20 Questions', d: 'Un court questionnaire guidé' },
                { t: 'Uploadez Vos Photos', d: '15 à 50 photos, simple et rapide' },
                { t: 'Découvrez Votre Prix Personnalisé', d: 'Offre claire et transparente' },
              ].map((s, i) => (
                <div key={i} className="glass rounded-2xl p-8">
                  <div className="text-white font-bold mb-2">{s.t}</div>
                  <div className="text-gray-300 text-sm">{s.d}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 px-4 bg-black">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-black text-center mb-12 text-white">Fonctionnalités Clés</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Galerie Interactive Avancée : Zoom, transitions Ken Burns, diaporama",
                "Timeline Chronologique : Jusqu'à 20 événements animés",
                "Compteur Temps Réel : Jours, mois, années depuis l’adoption",
                "Musique d’Ambiance : 15 morceaux libres de droits",
              ].map((txt, i) => (
                <div key={i} className="rounded-2xl border border-white/15 bg-white/5 p-6 flex items-start gap-3">
                  <span className="mt-1 inline-block w-2 h-2 rounded-full bg-red-500"></span>
                  <p className="text-gray-200 text-sm">{txt}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 px-4" style={{ backgroundColor: '#2a2f3b' }}>
          <h2 className="text-4xl font-black text-center mb-10 text-white">Témoignages</h2>
          <div className="carousel overflow-hidden">
            <div className="carousel-track flex gap-6 px-4">
              {[
                { name: "Sophie Martinez, Paris", pet: "Golden Retriever Max", text: "Reçu en 52 heures. La timeline est magnifique. Le compteur '2847 jours' nous a touchés aux larmes.", avatar: "https://i.pravatar.cc/150?img=12" },
                { name: "Thomas Leroy, Lyon", pet: "Chat Luna", text: "Animations et partage au top. Parfait pour toute la famille.", avatar: "https://i.pravatar.cc/150?img=25" },
                { name: "Camille Robert, Nantes", pet: "Néo", text: "Hébergement à vie rassurant, rendu sobre et élégant.", avatar: "https://i.pravatar.cc/150?img=9" },
                { name: "Marion Dubois, Lyon", pet: "Luna", text: "Upload intuitif, 53 consultations en deux semaines.", avatar: "https://i.pravatar.cc/150?img=31" },
                { name: "Yanis Karim, Lille", pet: "Nala", text: "Coup de cœur pour la musique d’ambiance.", avatar: "https://i.pravatar.cc/150?img=18" },
                { name: "Aïcha Benali, Paris", pet: "Milo", text: "Hommage émouvant, page dédiée parfaite.", avatar: "https://i.pravatar.cc/150?img=36" },
              ].concat([
                { name: "Sophie Martinez, Paris", pet: "Golden Retriever Max", text: "Reçu en 52 heures…", avatar: "https://i.pravatar.cc/150?img=12" },
                { name: "Thomas Leroy, Lyon", pet: "Chat Luna", text: "Animations et partage…", avatar: "https://i.pravatar.cc/150?img=25" },
                { name: "Camille Robert, Nantes", pet: "Néo", text: "Rendu sobre et élégant…", avatar: "https://i.pravatar.cc/150?img=9" },
              ]).map((t, i) => (
                <div key={i} className="flex-shrink-0 w-96 bg-white rounded-2xl p-6 shadow">
                  <div className="flex items-center gap-3 mb-3">
                    <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                      <div className="text-sm font-bold text-gray-900">{t.name}</div>
                      <div className="text-xs text-gray-600">{t.pet}</div>
                    </div>
                  </div>
                  <div className="mb-2">{"★★★★★"}</div>
                  <p className="text-gray-800 text-sm">{t.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 px-4 bg-black">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-black text-center mb-10 text-white">FAQ</h2>
            {[
              { q: "Quels formats de photos acceptez-vous ?", a: "JPG, PNG, HEIC. Minimum conseillé 1080px de large. Taille max 25MB/fichier. Optimisation automatique." },
              { q: "Puis-je modifier l'album après livraison ?", a: "Modifications incluses selon l’offre. Détails fournis après validation." },
              { q: "Comment fonctionne l'hébergement à vie ?", a: "Album privé, SSL, non indexé, engagement de 10 ans minimum." },
            ].map((faq, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass rounded-2xl mb-3">
                <button className="w-full p-5 text-left font-bold text-white flex justify-between items-center" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {faq.q}
                  <ChevronDown className={`w-5 h-5 text-red-500 transition ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {openFaq === i && <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="px-5 pb-5 text-gray-300 text-sm">{faq.a}</motion.div>}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="py-24 px-4" style={{ backgroundColor: '#7f1d1d' }}>
          <div className="text-center text-white max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-black mb-6">Découvrez Si Cette Offre Est Faite Pour Vous</h2>
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSfSKDA_ZWoBCn-5lpx5z5Jt6AScqkPYZhHWmBYTsR80mH85YA/viewform?usp=dialog" target="_blank" rel="noopener noreferrer" className="inline-block px-8 py-4 bg-white text-black rounded-full font-bold hover:opacity-90 transition">Commencer le Questionnaire</a>
          </div>
        </section>
      </div>
    );
  }

  if (page === 'quiz') {
    const q = questions[quizIndex];
    const val = answers[q.id];
    const setVal = v => setAnswers(a => ({ ...a, [q.id]: v }));
    const isAnswered = () => {
      if (!q.required) return true;
      if (q.type === 'checkbox') return Array.isArray(val) && val.length > 0;
      if (q.type === 'activities') return Array.isArray(val) && val.length > 0;
      if (q.type === 'photos') return photoItems.length > 0;
      return val !== undefined && val !== '' && val !== null;
    };
    const next = () => {
      if (quizIndex < questions.length - 1) setQuizIndex(quizIndex + 1);
      else setPage('result');
    };
    const prev = () => setQuizIndex(i => Math.max(0, i - 1));
    const percent = Math.round(((quizIndex + 1) / questions.length) * 100);
    return (
      <div className="min-h-screen bg-black text-white py-10 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <div className="h-2 bg-white/10 rounded">
              <div className="h-2 bg-red-600 rounded" style={{ width: `${percent}%` }} />
            </div>
            <div className="mt-2 text-sm text-gray-400">{quizIndex + 1} / {questions.length}</div>
          </div>
          <motion.div key={q.id} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} className="glass rounded-2xl p-6">
            <div className="text-xl font-bold mb-4">{q.label}</div>
            <div>
              {q.type === 'text' && (
                <input className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-gray-500"
                       type="text" value={val || ''} onChange={e => setVal(e.target.value)} />
              )}
              {q.type === 'textarea' && (
                <>
                  <textarea className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-gray-500"
                            rows="6" value={val || ''} onChange={e => setVal(e.target.value)} />
                  <div className="text-xs text-gray-400 mt-1">{(val?.length || 0)} / {(q.max || 500)}</div>
                </>
              )}
              {q.type === 'select' && (
                <select className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white" value={val || ''}
                        onChange={e => setVal(e.target.value)}>
                  <option value="" disabled>Choisir…</option>
                  {q.options.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              )}
              {q.type === 'cards' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {q.options.map(o => (
                    <div key={o}
                         onClick={() => setVal(o)}
                         className={`p-6 rounded-2xl border text-center cursor-pointer transition ${
                           val === o ? 'border-red-500 bg-white/10' : 'border-white/10 bg-white/5'
                         } hover:scale-[1.02]`}>
                      <div className="text-lg font-bold">{o}</div>
                      {val === o && <div className="mt-2 inline-block px-2 py-1 text-xs rounded-full bg-red-600 text-white">Sélectionné</div>}
                    </div>
                  ))}
                </div>
              )}
              {q.type === 'activities' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {(q.options || []).map(o => {
                    const arr = Array.isArray(val) ? val : [];
                    const selected = arr.includes(o);
                    const toggled = selected ? arr.filter(x => x !== o) : [...arr, o];
                    return (
                      <button key={o} type="button"
                              onClick={() => setVal(toggled)}
                              className={`p-3 rounded-xl border text-sm ${
                                selected ? 'border-red-500 bg-white/10' : 'border-white/10 bg-white/5'
                              }`}>
                        {o}
                      </button>
                    );
                  })}
                </div>
              )}
              {q.type === 'radio' && (
                <div className="grid gap-3">
                  {q.options.map(o => (
                    <label key={o} className={`flex items-center gap-3 p-3 rounded-xl border ${val === o ? 'border-red-500 bg-white/10' : 'border-white/10 bg-white/5'}`}>
                      <input type="radio" className="accent-red-600" checked={val === o} onChange={() => setVal(o)} />
                      <span>{o}</span>
                    </label>
                  ))}
                </div>
              )}
              {q.type === 'checkbox' && (
                <div className="grid gap-3">
                  {q.options.map(o => {
                    const arr = Array.isArray(val) ? val : [];
                    const toggled = arr.includes(o) ? arr.filter(x => x !== o) : [...arr, o];
                    return (
                      <label key={o} className="flex items-center gap-3 p-3 rounded-xl border border-white/10 bg-white/5">
                        <input type="checkbox" className="accent-red-600" checked={arr.includes(o)} onChange={() => setVal(toggled)} />
                        <span>{o}</span>
                      </label>
                    );
                  })}
                </div>
              )}
              {q.type === 'date' && (
                <input type="date" className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white" value={val || ''} onChange={e => setVal(e.target.value)} />
              )}
              {q.type === 'range' && (
                <div>
                  <input type="range" min={q.min} max={q.max} value={val || 0} onChange={e => setVal(Number(e.target.value))} className="w-full accent-red-600" />
                  <div className="text-sm text-gray-400 mt-1">{val || 0} ans</div>
                </div>
              )}
              {q.type === 'style' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {['Classique Élégant', 'Moderne Coloré', 'Nostalgique Sépia'].map(s => (
                    <div key={s} onClick={() => setVal(s)}
                         className={`rounded-2xl p-4 border cursor-pointer transition ${val === s ? 'border-red-500 bg-white/10' : 'border-white/10 bg-white/5'}`}>
                      <div className="h-28 rounded-xl mb-3" style={{ background: s === 'Classique Élégant' ? 'linear-gradient(135deg, #e5e7eb, #d1d5db)' : s === 'Moderne Coloré' ? 'linear-gradient(135deg, #ef4444, #7c3aed)' : 'linear-gradient(135deg, #a16207, #713f12)' }} />
                      <div className="font-bold">{s}</div>
                    </div>
                  ))}
                </div>
              )}
              {q.type === 'photos' && (
                <div>
                  <div onDragOver={e => e.preventDefault()}
                       onDrop={e => {
                         e.preventDefault();
                         const files = Array.from(e.dataTransfer.files || []).filter(f => /^image\//.test(f.type));
                         const allowed = files.slice(0, Math.max(0, 50 - photoItems.length));
                         const next = allowed.map(f => ({ file: f, url: URL.createObjectURL(f) }));
                         setPhotoItems(prev => [...prev, ...next]);
                       }}
                       className="border-2 border-dashed border-white/20 rounded-2xl p-8 text-center bg-white/5">
                    <div className="text-2xl mb-2">📸 Glissez vos photos ici</div>
                    <div className="text-sm text-gray-400">ou cliquez pour sélectionner (JPG/PNG/HEIC, 10MB max, 50 max)</div>
                    <input type="file" multiple accept="image/*" onChange={e => {
                      const files = Array.from(e.target.files || []).filter(f => /^image\//.test(f.type));
                      const allowed = files.slice(0, Math.max(0, 50 - photoItems.length));
                      const next = allowed.map(f => ({ file: f, url: URL.createObjectURL(f) }));
                      setPhotoItems(prev => [...prev, ...next]);
                    }} className="mt-4" />
                  </div>
                  {photoItems.length > 0 && (
                    <>
                      <div className="grid grid-cols-3 gap-3 mt-4">
                        {photoItems.map((p, i) => (
                          <div key={i} className="relative">
                            <img src={p.url} alt="" className="w-full h-24 object-cover rounded-xl border border-white/10" />
                            <button type="button" onClick={() => {
                              URL.revokeObjectURL(p.url);
                              setPhotoItems(items => items.filter((_, idx) => idx !== i));
                            }} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-600 text-white text-xs">X</button>
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 text-sm text-gray-300">✅ {photoItems.length} photo(s) ajoutée(s)</div>
                    </>
                  )}
                </div>
              )}
              {q.type === 'videos' && (
                <div>
                  <div onDragOver={e => e.preventDefault()}
                       onDrop={e => {
                         e.preventDefault();
                         const files = Array.from(e.dataTransfer.files || []).filter(f => /^video\//.test(f.type));
                         const allowed = files.slice(0, Math.max(0, 5 - videoItems.length));
                         const next = allowed.map(f => ({ file: f, url: URL.createObjectURL(f) }));
                         setVideoItems(prev => [...prev, ...next]);
                       }}
                       className="border-2 border-dashed border-white/20 rounded-2xl p-8 text-center bg-white/5">
                    <div className="text-2xl mb-2">🎥 Glissez vos vidéos ici</div>
                    <div className="text-sm text-gray-400">MP4/MOV, 30s max, 50MB max, jusqu’à 5 vidéos</div>
                    <input type="file" multiple accept="video/*" onChange={e => {
                      const files = Array.from(e.target.files || []).filter(f => /^video\//.test(f.type));
                      const allowed = files.slice(0, Math.max(0, 5 - videoItems.length));
                      const next = allowed.map(f => ({ file: f, url: URL.createObjectURL(f) }));
                      setVideoItems(prev => [...prev, ...next]);
                    }} className="mt-4" />
                  </div>
                  {videoItems.length > 0 && (
                    <>
                      <div className="grid grid-cols-2 gap-3 mt-4">
                        {videoItems.map((v, i) => (
                          <div key={i} className="relative">
                            <video src={v.url} className="w-full h-28 object-cover rounded-xl border border-white/10" controls />
                            <button type="button" onClick={() => {
                              URL.revokeObjectURL(v.url);
                              setVideoItems(items => items.filter((_, idx) => idx !== i));
                            }} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-600 text-white text-xs">X</button>
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 text-sm text-gray-300">✅ {videoItems.length} vidéo(s) ajoutée(s)</div>
                      <button type="button" onClick={() => setVideoItems([])} className="mt-2 px-3 py-2 bg-white/10 rounded-full">Passer cette étape</button>
                    </>
                  )}
                </div>
              )}
            </div>
          </motion.div>
          <div className="flex gap-3 mt-6">
            <button onClick={prev} disabled={quizIndex === 0} className="flex-1 py-4 bg-white/5 rounded-full font-bold disabled:opacity-30">← Précédent</button>
            <button onClick={next} disabled={!isAnswered()} className="flex-1 py-4 bg-red-600 rounded-full font-bold disabled:opacity-30">Suivant →</button>
          </div>
        </div>
      </div>
    );
  }

  if (page === 'result') {
    const name = answers.petName || 'Votre compagnon';
    const buildPrefillUrl = () => {
      let base = formBaseUrl || 'https://forms.gle/your-form-id';
      let map = {};
      try { map = JSON.parse(formMappingText || '{}') } catch { map = {} }
      const u = new URL(base);
      const setField = (key, value) => {
        const entry = map[key];
        if (entry && value !== undefined && value !== null && value !== '') {
          u.searchParams.append(entry, Array.isArray(value) ? value.join(', ') : String(value));
        }
      };
      setField('petName', answers.petName);
      setField('petType', answers.petType);
      setField('petBreed', answers.petBreed);
      setField('personality', answers.personality);
      setField('bestMemory', answers.bestMemory);
      setField('activities', answers.activities);
      setField('style', answers.style);
      setField('timeline', answers.timeline);
      setField('counter', answers.counter);
      setField('delivery', answers.delivery);
      setField('deliveryName', answers.deliveryName);
      setField('deliveryEmail', answers.deliveryEmail);
      if (photoUrls.length > 0) setField('photos_urls', photoUrls.join('\n'));
      if (videoUrls.length > 0) setField('videos_urls', videoUrls.join('\n'));
      return u.toString();
    };
    const formUrl = buildPrefillUrl();

    const uploadToCloudinary = async (file, type) => {
      if (!cloudName || !uploadPreset) throw new Error('Cloudinary non configuré');
      const endpoint = `https://api.cloudinary.com/v1_1/${cloudName}/${type}/upload`;
      const fd = new FormData();
      fd.append('file', file);
      fd.append('upload_preset', uploadPreset);
      const res = await fetch(endpoint, { method: 'POST', body: fd });
      if (!res.ok) throw new Error('Upload échoué');
      const data = await res.json();
      return data.secure_url;
    };

    const handleCloudUpload = async () => {
      try {
        setUploading(true);
        const pUrls = [];
        for (const p of photoItems) {
          const url = await uploadToCloudinary(p.file, 'image');
          pUrls.push(url);
        }
        const vUrls = [];
        for (const v of videoItems) {
          const url = await uploadToCloudinary(v.file, 'video');
          vUrls.push(url);
        }
        setPhotoUrls(pUrls);
        setVideoUrls(vUrls);
      } catch {
        alert('Erreur lors de l’upload Cloud. Vérifiez cloudName et uploadPreset.');
      } finally {
        setUploading(false);
      }
    };
    return (
      <div className="min-h-screen bg-black text-white py-10 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-black mb-4">Votre Album Mémoire Personnalisé Pour {name}</h1>
          <div className="glass rounded-2xl p-8 mb-6">
            <div className="text-xl font-bold mb-3">Prix de votre album complet et personnalisé</div>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-6xl font-black text-red-500">3,99€</motion.div>
            <div className="mt-4 text-gray-300 text-sm">Prix unique, tout inclus. Aucun abonnement.</div>
          </div>
          <div className="glass rounded-2xl p-6 mb-6 text-left">
            <div className="font-bold mb-2">Uploader vers le Cloud (optionnel)</div>
            <div className="grid md:grid-cols-2 gap-3">
              <input value={cloudName} onChange={e=>setCloudName(e.target.value)} placeholder="Cloudinary cloud name" className="p-3 bg-white/5 border border-white/10 rounded-xl text-white" />
              <input value={uploadPreset} onChange={e=>setUploadPreset(e.target.value)} placeholder="Upload preset (unsigned)" className="p-3 bg-white/5 border border-white/10 rounded-xl text-white" />
            </div>
            <div className="mt-3 flex gap-3">
              <button onClick={handleCloudUpload} disabled={uploading || !cloudName || !uploadPreset} className="px-4 py-3 bg-red-600 rounded-full font-bold disabled:opacity-30">Uploader vers Cloudinary</button>
              {uploading && <span className="text-sm text-gray-400 mt-3">Upload en cours…</span>}
            </div>
            {(photoUrls.length>0 || videoUrls.length>0) && (
              <div className="text-sm text-gray-300 mt-3">
                Photos uploadées: {photoUrls.length} • Vidéos uploadées: {videoUrls.length}
              </div>
            )}
          </div>
          <div className="glass rounded-2xl p-6 mb-6 text-left">
            <div className="font-bold mb-2">Google Form (pré-remplissage)</div>
            <input value={formBaseUrl} onChange={e=>setFormBaseUrl(e.target.value)} placeholder="URL du Google Form (pré-rempli/base)" className="w-full p-3 bg-white/5 border border-white/10 rounded-xl text-white mb-3" />
            <textarea value={formMappingText} onChange={e=>setFormMappingText(e.target.value)} rows="6" className="w-full p-3 bg-white/5 border border-white/10 rounded-xl text-white" placeholder='{"petName":"entry.123456", ...}' />
            <div className="mt-2 text-xs text-gray-400 break-all">{formUrl}</div>
          </div>
          <div className="grid md:grid-cols-2 gap-4 text-left mb-6">
            <div className="glass rounded-2xl p-6">
              <div className="font-bold mb-2">Récapitulatif</div>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>Animal: {answers.petType || '—'} {answers.petBreed ? `• ${answers.petBreed}` : ''}</li>
                <li>Photos: {photoItems.length}</li>
                <li>Vidéos: {videoItems.length}</li>
                <li>Style: {answers.style || '—'}</li>
                <li>Livraison: {answers.delivery || '—'}</li>
              </ul>
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="font-bold mb-2">Inclus</div>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>Timeline animée</li>
                <li>Galerie immersive</li>
                <li>Compteur temps réel</li>
                <li>Hébergement à vie</li>
                <li>PDF téléchargeable</li>
              </ul>
            </div>
          </div>
          <div className="flex gap-3 justify-center">
            <a href={formUrl.toString()} className="px-6 py-4 bg-red-600 rounded-full font-bold text-white hover:bg-red-700 transition">Finaliser Mon Album à 3,99€</a>
            <button onClick={() => alert('Un lien de reprise vous sera envoyé par email.')} className="px-6 py-4 bg-white/10 rounded-full font-bold">Sauvegarder et revenir plus tard</button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
